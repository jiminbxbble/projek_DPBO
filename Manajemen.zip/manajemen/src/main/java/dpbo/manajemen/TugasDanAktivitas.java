package dpbo.manajemen;

import java.util.*;

public interface TugasDanAktivitas {
    void jadwalkanTugas(String tugas, Date tanggal);
    List<String> rekapAktivitas();
}
