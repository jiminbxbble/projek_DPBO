package dpbo.manajemen;

public interface Manajerial {
    String tampilkanInfoManajemen();
    String getNamaManajer();
    void setNamaManajer(String nama);
    String getUnitKerja();
    void setUnitKerja(String unit);
    String getStatusOperasional();
    void setStatusOperasional(String status);
}

