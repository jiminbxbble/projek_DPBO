package dpbo.manajemen;

public interface StatusSistem {
    String tampilkanStatusSistem();
    void aktifkanUnit();
    void nonaktifkanUnit();
}

