package dpbo.BookDPBO;

import java.util.Date;

public interface LaporanInterface {
    void generateLaporanPenjualan();
    double hitungRataRataPenjualan();
    String tampilkanLaporan();
    String bandingkanPeriode(Date tglAwal, Date tglAkhir);
    double getTotalPenjualan();
    void setTotalPenjualan(double total);
    int getJumlahBukuTerjual();
    void setJumlahBukuTerjual(int jumlah);
}
