package dpbo.BookDPBO;

public class Transfer extends Transaksi implements Pembayaran {
    private String bank;
    private String noVirtualAccount;

    public Transfer(String tanggal, String nama, String alamat, String buku, int jumlah,
                    int totalHarga, String bank, String noVirtualAccount) {
        super(tanggal, nama, alamat, buku, jumlah, totalHarga);
        this.bank = bank;
        this.noVirtualAccount = noVirtualAccount;
    }

    public Transfer() {
        super("", "", "", "", 0, 0);
        this.bank = "Mandiri";
        this.noVirtualAccount = "1234567890";
    }

    public String getNoVirtualAccount() {
        return noVirtualAccount;
    }

    public void setNoVirtualAccount(String noVA) {
        this.noVirtualAccount = noVA;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    @Override
    public void bayar() {
        System.out.println("Pembayaran melalui transfer ke bank " + bank + 
                           " dengan VA " + noVirtualAccount + " berhasil.");
    }

    @Override
    public void prosesPembayaran() {
        System.out.println("Memproses pembayaran melalui Transfer...");
        bayar();
    }
}
