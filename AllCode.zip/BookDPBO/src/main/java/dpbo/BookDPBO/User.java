package dpbo.BookDPBO;

public abstract class User {
    protected String nama;
    protected String password;

    public User(String nama, String password) {
        this.nama = nama;
        this.password = password;
    }

    public String getNama() {
        return nama;
    }

    public String getPassword() {
        return password;
    }

    public void login() {
        System.out.println(nama + " login berhasil.");
    }

    public void logout() {
        System.out.println(nama + " logout.");
    }
    
    abstract void tampilkanInfo();
}

