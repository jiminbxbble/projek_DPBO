package dpbo.BookDPBO;

import java.util.*;

public class Manajemen implements Manajerial, StatusSistem, TugasDanAktivitas {
    protected String idManajemen = "16APR";
    protected String namaManajer;
    protected String jabatan = "Manajer Toko";
    protected Date tanggalDibuat;
    protected String unitKerja;
    protected List<String> daftarTugas = new ArrayList<>();
    protected List<String> logAktivitas = new ArrayList<>();
    protected String statusOperasional;

    public void kelolaPengiriman() {
        logAktivitas.add("Pengiriman dikelola oleh " + namaManajer + " pada " + new Date());
    }

    public void kelolaLaporanPenjualan() {
        logAktivitas.add("Laporan penjualan dikelola oleh " + namaManajer + " pada " + new Date());
    }

    public String tampilkanStatusSistem() {
        return "Status operasional unit " + unitKerja + ": " + statusOperasional;
    }

    public void jadwalkanTugas(String tugas, Date tanggal) {
        daftarTugas.add(tugas + " (tanggal: " + tanggal.toString() + ")");
        logAktivitas.add("Tugas dijadwalkan: " + tugas + " pada " + tanggal);
    }

    public List<String> rekapAktivitas() {
        return new ArrayList<>(logAktivitas);
    }

    public void aktifkanUnit() {
        statusOperasional = "Aktif";
        logAktivitas.add("Unit " + unitKerja + " diaktifkan");
    }

    public void nonaktifkanUnit() {
        statusOperasional = "Nonaktif";
        logAktivitas.add("Unit " + unitKerja + " dinonaktifkan");
    }

    public String tampilkanInfoManajemen() {
        return "ID: " + idManajemen +
                ", Nama Manajer: " + namaManajer +
                ", Unit: " + unitKerja +
                ", Jabatan: " + jabatan +
                ", Status: " + statusOperasional;
    }

    public String getNamaManajer() {
        return namaManajer;
    }

    public void setNamaManajer(String nama) {
        this.namaManajer = nama;
    }

    public String getUnitKerja() {
        return unitKerja;
    }

    public void setUnitKerja(String unit) {
        this.unitKerja = unit;
    }

    public String getStatusOperasional() {
        return statusOperasional;
    }

    public void setStatusOperasional(String status) {
        this.statusOperasional = status;
    }

	@Override
	public void kendalikan() {
	    System.out.println("Manajerial: Mengendalikan operasional toko...");
	    System.out.println(tampilkanInfoManajemen());
	    System.out.println(tampilkanStatusSistem());

	    if (!daftarTugas.isEmpty()) {
	        System.out.println("Tugas yang dijadwalkan:");
	        for (String tugas : daftarTugas) {
	            System.out.println("- " + tugas);
	        }
	    } else {
	        System.out.println("Belum ada tugas dijadwalkan.");
	    }
	}

	@Override
	public void rencanakan() {
	    System.out.println("Merencanakan strategi manajemen toko...");
	    jadwalkanTugas("Review stok dan penjualan", new Date());
	}

	@Override
	public void laksanakanTugas() {
	    System.out.println("Melaksanakan seluruh tugas terjadwal...");
	    for (String tugas : daftarTugas) {
	        System.out.println("Menjalankan: " + tugas);
	    }
	}

}
