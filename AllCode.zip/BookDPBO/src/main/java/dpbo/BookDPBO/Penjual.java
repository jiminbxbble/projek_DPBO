package dpbo.BookDPBO;

public class Penjual extends User implements KelolaToko {

    public Penjual(String nama, String password) {
        super(nama, password);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Nama Penjual: " + getNama());
    }

    @Override
    public void tambahBarang(String barang) {
        System.out.println("Menambahkan barang: " + barang);
    }

    @Override
    public void hapusBarang(String barang) {
        System.out.println("Menghapus barang: " + barang);
    }

    @Override
    public void beliBarang(String barang, int jumlah) {
        System.out.println("Membeli " + jumlah + " unit dari " + barang);
    }

    @Override
    public void bayarBarang(double total) {
        System.out.println("Membayar total: Rp" + total);
    }

    @Override
    public void kelola() {
        System.out.println("=== Mengelola toko ===");
        tambahBarang("Buku Pemrograman");
        beliBarang("Buku Pemrograman", 5);
        bayarBarang(250000);
        hapusBarang("Buku Lama");
    }
}
