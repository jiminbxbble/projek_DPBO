package dpbo.BookDPBO;

	public class Buku extends Produk {
	    private String judulBuku;
	    private String penulis;
	    private String genre;
	    
		public Buku(String nama, double harga, int stok, String judulBuku, String penulis, String genre) {
			super(nama, harga,stok);
			
			 if (harga < 0) {
			        throw new IllegalArgumentException("[ERROR] Harga tidak boleh negatif.");
			    }
			    if (stok < 0) {
			        throw new IllegalArgumentException("[ERROR] Stok tidak boleh negatif.");
			    }
			    
			this.judulBuku = judulBuku;
			this.penulis = penulis;
			this.genre = genre;
		}
		
		public String getJudulBuku() {
			return judulBuku;
		}

		public void setJudulBuku(String judulBuku) {
			this.judulBuku = judulBuku;
		}
		
		public String getPenulis() {
			return penulis;
		}

		public void setPenulis(String penulis) {
			this.penulis = penulis;
		}

		public String getGenre() {
			return genre;
		}

		public void setGenre(String genre) {
			this.genre = genre;
		}

		@Override
		public String toString() {
			return super.toString() + "\n\n Judul Buku: " + judulBuku + "\n penulis: " + penulis + "\n Genre: " + genre;
		}
}
