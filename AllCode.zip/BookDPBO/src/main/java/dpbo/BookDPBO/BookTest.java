package dpbo.BookDPBO;

import java.util.*;

public class BookTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Buku buku = new Buku("Novel", 75000, 20, "Laut Bercerita", "Leila S. Chudori", "Fiksi");
        Penjual penjual = new Penjual("Ani", "ani123");
        Pembeli pembeli = new Pembeli("Budi", "budi456");
        Pengiriman kirim = new Pengiriman("B123", "Bandung", "Dalam Pengiriman");

        int role;
        System.out.println("=== SELAMAT DATANG DI TOKO BUKU ===");
        System.out.println("Login sebagai:");
        System.out.println("1. Pembeli");
        System.out.println("2. Penjual");
        System.out.print("Pilihan Anda: ");
        role = input.nextInt();

        if (role == 1) {
            pembeliMenu(input, pembeli, penjual, buku, kirim);
        } else if (role == 2) {
            penjualMenu(input, penjual, buku);
        } else {
            System.out.println("Pilihan tidak valid. Program dihentikan.");
        }

        input.close();
    }

    // === MENU PEMBELI ===
    public static void pembeliMenu(Scanner input, Pembeli pembeli, Penjual penjual, Buku buku, Pengiriman kirim) {
        int pilihan;
        do {
            System.out.println("\n=== MENU PEMBELI ===");
            System.out.println("1. Lihat Informasi Buku");
            System.out.println("2. Beli Buku");
            System.out.println("3. Proses Pembayaran");
            System.out.println("4. Lihat Diskon");
            System.out.println("5. Kirim Barang");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();

            switch (pilihan) {
                case 1:
                    System.out.println("\n--- Informasi Buku ---");
                    System.out.println(buku.toString());
                    break;
                case 2:
                    System.out.print("Jumlah yang ingin dibeli: ");
                    int jumlah = input.nextInt();
                    Transaksi transaksi = new Transaksi(
                        new Date().toString(),
                        pembeli.getNama(),
                        kirim.getAlamatTujuan(),
                        buku.getJudulBuku(),
                        jumlah,
                        (int)(buku.getHarga() * jumlah)
                    );
                    transaksi.prosesTransaksi();
                    break;
                case 3:
                    System.out.println("Metode Pembayaran:");
                    System.out.println("1. Tunai");
                    System.out.println("2. Transfer");
                    int metode = input.nextInt();

                    if (metode == 1) {
                        Tunai tunai = new Tunai(new Date().toString(), pembeli.getNama(), kirim.getAlamatTujuan(), buku.getJudulBuku(), 1, (int)buku.getHarga(), false);
                        tunai.bayar();
                    } else {
                        Transfer transfer = new Transfer(new Date().toString(), pembeli.getNama(), kirim.getAlamatTujuan(), buku.getJudulBuku(), 1, (int)buku.getHarga(), "BCA", "1234567890");
                        transfer.bayar();
                    }
                    break;
                case 4:
                    Diskon diskon = new Diskon(buku.getJudulBuku(), buku.getHarga(), buku.getStok(), 10);
                    System.out.println("\n--- Diskon Diberikan ---");
                    System.out.println(diskon.toString());
                    break;
                case 5:
                    Pengiriman tujuan = new Pengiriman("JNE", "Bandung", "Jakarta");
                    tujuan.kirimBarang();
                    break;
                case 0:
                    System.out.println("Terima kasih telah berbelanja!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }

        } while (pilihan != 0);
    }

    // === MENU PENJUAL ===
    public static void penjualMenu(Scanner input, Penjual penjual, Buku buku) {
        int pilihan;
        do {
            System.out.println("\n=== MENU PENJUAL ===");
            System.out.println("1. Lihat Informasi Penjual");
            System.out.println("2. Lihat Laporan Penjualan");
            System.out.println("3. Kelola Toko");
            System.out.println("4. Laksanakan Tugas");
            System.out.println("5. Manajemen & Manajerial");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();

            switch (pilihan) {
                case 1:
                    System.out.println("\n--- Info Penjual ---");
                    penjual.tampilkanInfo();
                    break;
                case 2:
                    Calendar cal = Calendar.getInstance();
                    Date tglAkhir = cal.getTime();
                    cal.add(Calendar.DATE, -7);
                    Date tglAwal = cal.getTime();

                    LaporanPenjualan laporan = new LaporanPenjualan(
                        "L001",
                        "Fiksi",
                        tglAwal,
                        tglAkhir,
                        1500000,
                        20
                    );
                    laporan.generateLaporanPenjualan();
                    laporan.hitungRataRataPenjualan();
                    System.out.println(laporan.tampilkanLaporan());
                    break;
                case 3:
                    KelolaToko kelola = new KelolaToko() {
                        @Override
                        public void tambahBarang(String barang) {
                            System.out.println("Menambahkan barang: " + barang);
                        }

                        @Override
                        public void hapusBarang(String barang) {
                            System.out.println("Menghapus barang: " + barang);
                        }

                        @Override
                        public void beliBarang(String barang, int jumlah) {
                            System.out.println("Membeli " + jumlah + " dari " + barang);
                        }

                        @Override
                        public void bayarBarang(double total) {
                            System.out.println("Membayar sebesar Rp " + total);
                        }

                        @Override
                        public void kelola() {
                            System.out.println("Mengelola toko buku...");
                            tambahBarang("Buku Baru");
                            hapusBarang("Buku Lama");
                            beliBarang("Novel", 5);
                            bayarBarang(375000);
                        }
                    };
                    kelola.kelola();
                    break;
                case 4:
                    TugasDanAktivitas tugas = new TugasDanAktivitas() {
                        private List<String> aktivitas = new ArrayList<>();

                        @Override
                        public void jadwalkanTugas(String tugas, Date tanggal) {
                            aktivitas.add(tugas + " - " + tanggal.toString());
                        }

                        @Override
                        public List<String> rekapAktivitas() {
                            return aktivitas;
                        }

                        @Override
                        public void laksanakanTugas() {
                            System.out.println("Melaksanakan tugas harian toko...");
                            jadwalkanTugas("Stok ulang buku", new Date());
                            for (String a : rekapAktivitas()) {
                                System.out.println("Aktivitas: " + a);
                            }
                        }
                    };
                    tugas.laksanakanTugas();
                    break;
                case 5:
                    Manajemen manajemen = new Manajemen();
                    
                    manajemen.setNamaManajer("Pak Jie");
                    manajemen.setUnitKerja("Operasional");
                    manajemen.setStatusOperasional("Aktif");
                    manajemen.jadwalkanTugas("Review stok dan penjualan", new Date());
                   
                    manajemen.rencanakan();
                    manajemen.kendalikan();
                    break;
                case 0:
                    System.out.println("Terima kasih telah mengelola toko.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }

        } while (pilihan != 0);
    }
}
