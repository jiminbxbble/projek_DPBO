package dpbo.BookDPBO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BookstoreUI {
    static ArrayList<Buku> daftarBuku = new ArrayList<>();
    static Penjual penjual = new Penjual("Ani", "Jakarta", "ani@gmail.com");
    static Pembeli pembeli = new Pembeli("Budi", "Bandung", "budi@gmail.com");

    public static void main(String[] args) {
        daftarBuku.add(new Buku("Novel", 75000, 20, "Laut Bercerita", "Leila S. Chudori", "Fiksi"));
        daftarBuku.add(new Buku("Novel", 65000, 15, "Bumi", "Tere Liye", "Fantasi"));
        SwingUtilities.invokeLater(() -> new LoginFrame());
    }
}

class LoginFrame extends JFrame {
    public LoginFrame() {
        setTitle("Toko Buku - Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JButton pembeliBtn = new JButton("Masuk sebagai Pembeli");
        JButton penjualBtn = new JButton("Masuk sebagai Penjual");

        pembeliBtn.addActionListener(e -> {
            new PembeliFrame();
            dispose();
        });

        penjualBtn.addActionListener(e -> {
            new PenjualFrame();
            dispose();
        });

        panel.add(new JLabel("Pilih peran Anda:", SwingConstants.CENTER));
        panel.add(pembeliBtn);
        panel.add(penjualBtn);

        add(panel);
        setVisible(true);
    }
}

class PembeliFrame extends JFrame {
    public PembeliFrame() {
        setTitle("Menu Pembeli");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 1));
        panel.add(new JLabel("Menu Pembeli", SwingConstants.CENTER));

        JButton infoBtn = new JButton("Lihat Informasi Buku");
        infoBtn.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Buku b : BookstoreUI.daftarBuku) {
                sb.append(b.toString()).append("\n\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        });

        JButton beliBtn = new JButton("Beli Buku");
        beliBtn.addActionListener(e -> {
            String[] judulBuku = BookstoreUI.daftarBuku.stream().map(Buku::getJudulBuku).toArray(String[]::new);
            String pilihan = (String) JOptionPane.showInputDialog(null, "Pilih buku:", "Beli Buku",
                    JOptionPane.QUESTION_MESSAGE, null, judulBuku, judulBuku[0]);

            if (pilihan != null) {
                String input = JOptionPane.showInputDialog("Jumlah yang ingin dibeli:");
                try {
                    int jumlah = Integer.parseInt(input);
                    Buku bukuDipilih = BookstoreUI.daftarBuku.stream().filter(b -> b.getJudulBuku().equals(pilihan)).findFirst().orElse(null);
                    Transaksi transaksi = new Transaksi(BookstoreUI.penjual, BookstoreUI.pembeli, bukuDipilih, jumlah);
                    transaksi.prosesTransaksi();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Input tidak valid.");
                }
            }
        });

        JButton bayarBtn = new JButton("Proses Pembayaran");
        bayarBtn.addActionListener(e -> {
            String[] metode = {"Tunai", "Transfer"};
            int pilihan = JOptionPane.showOptionDialog(null, "Pilih metode pembayaran:", "Pembayaran",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, metode, metode[0]);
            Pembayaran pembayaran = (pilihan == 0) ? new Tunai() : new Transfer();
            pembayaran.prosesPembayaran();
        });

        JButton diskonBtn = new JButton("Lihat Diskon");
        diskonBtn.addActionListener(e -> {
            Diskon diskon = new Diskon(10);
            JOptionPane.showMessageDialog(null, "Diskon: " + diskon.getPersenDiskon() + "%");
        });

        JButton kirimBtn = new JButton("Kirim Barang");
        kirimBtn.addActionListener(e -> {
            Pengiriman kirim = new Pengiriman("JNE", BookstoreUI.pembeli.getAlamat(), BookstoreUI.penjual.getAlamat());
            kirim.kirimBarang();
        });

        panel.add(infoBtn);
        panel.add(beliBtn);
        panel.add(bayarBtn);
        panel.add(diskonBtn);
        panel.add(kirimBtn);

        add(panel);
        setVisible(true);
    }
}

class PenjualFrame extends JFrame {
    public PenjualFrame() {
        setTitle("Menu Penjual");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(7, 1));
        panel.add(new JLabel("Menu Penjual", SwingConstants.CENTER));

        JButton crudBtn = new JButton("Kelola Buku (CRUD)");
        crudBtn.addActionListener(e -> new BukuCRUDFrame());

        JButton infoBtn = new JButton("Lihat Informasi Penjual");
        infoBtn.addActionListener(e -> BookstoreUI.penjual.tampilkanInfo());

        JButton laporanBtn = new JButton("Lihat Laporan Penjualan");
        laporanBtn.addActionListener(e -> new LaporanPenjualan().tampilkanLaporan());

        JButton kelolaBtn = new JButton("Kelola Toko");
        kelolaBtn.addActionListener(e -> new KelolaToko().kelola());

        JButton tugasBtn = new JButton("Laksanakan Tugas");
        tugasBtn.addActionListener(e -> new TugasDanAktivitas().laksanakanTugas());

        JButton manajemenBtn = new JButton("Manajemen & Manajerial");
        manajemenBtn.addActionListener(e -> {
            new Manajemen().rencanakan();
            new Manajerial().kendalikan();
        });

        panel.add(crudBtn);
        panel.add(infoBtn);
        panel.add(laporanBtn);
        panel.add(kelolaBtn);
        panel.add(tugasBtn);
        panel.add(manajemenBtn);

        add(panel);
        setVisible(true);
    }
}

class BukuCRUDFrame extends JFrame {
    public BukuCRUDFrame() {
        setTitle("CRUD Buku");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 1));

        JButton tambahBtn = new JButton("Tambah Buku");
        tambahBtn.addActionListener(e -> {
        	String nama = JOptionPane.showInputDialog("Nama Pembeli:");
            String judul = JOptionPane.showInputDialog("Judul:");
            String penulis = JOptionPane.showInputDialog("Penulis:");
            String genre = JOptionPane.showInputDialog("Genre:");
            int harga = Integer.parseInt(JOptionPane.showInputDialog("Harga:"));
            int stok = Integer.parseInt(JOptionPane.showInputDialog("Stok:"));
            BookstoreUI.daftarBuku.add(new Buku(nama, harga, stok, judul, penulis, genre));
            JOptionPane.showMessageDialog(null, "Buku berhasil ditambahkan.");
        });

        JButton lihatBtn = new JButton("Lihat Semua Buku");
        lihatBtn.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Buku b : BookstoreUI.daftarBuku) {
                sb.append(b.toString()).append("\n\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        });

        JButton editBtn = new JButton("Edit Buku");
        editBtn.addActionListener(e -> {
            String[] judulBuku = BookstoreUI.daftarBuku.stream().map(Buku::getJudulBuku).toArray(String[]::new);
            String pilihan = (String) JOptionPane.showInputDialog(null, "Pilih buku:", "Edit Buku",
                    JOptionPane.QUESTION_MESSAGE, null, judulBuku, judulBuku[0]);

            Buku buku = BookstoreUI.daftarBuku.stream().filter(b -> b.getJudulBuku().equals(pilihan)).findFirst().orElse(null);
            if (buku != null) {
                buku.setJudul(JOptionPane.showInputDialog("Judul baru:", buku.getJudulBuku()));
                buku.setPenulis(JOptionPane.showInputDialog("Penulis baru:", buku.getPenulis()));
                buku.setGenre(JOptionPane.showInputDialog("Genre baru:", buku.getGenre()));
                buku.setHarga(Integer.parseInt(JOptionPane.showInputDialog("Harga baru:", buku.getHarga())));
                buku.setStok(Integer.parseInt(JOptionPane.showInputDialog("Stok baru:", buku.getStok())));
                JOptionPane.showMessageDialog(null, "Data buku diperbarui.");
            }
        });

        JButton hapusBtn = new JButton("Hapus Buku");
        hapusBtn.addActionListener(e -> {
            String[] judulBuku = BookstoreUI.daftarBuku.stream().map(Buku::getJudulBuku).toArray(String[]::new);
            String pilihan = (String) JOptionPane.showInputDialog(null, "Pilih buku:", "Hapus Buku",
                    JOptionPane.QUESTION_MESSAGE, null, judulBuku, judulBuku[0]);
            BookstoreUI.daftarBuku.removeIf(b -> b.getJudulBuku().equals(pilihan));
            JOptionPane.showMessageDialog(null, "Buku berhasil dihapus.");
        });

        panel.add(tambahBtn);
        panel.add(lihatBtn);
        panel.add(editBtn);
        panel.add(hapusBtn);

        add(panel);
        setVisible(true);
    }
}
