package dpbo.BookDPBO;

public interface Pembayaran {
	public void bayar();

	public void prosesPembayaran();
}
