package dpbo.BookDPBO;

public interface PengirimanInterface {
    void aturPengiriman(String pesananId);
    void updateStatusPengiriman(String id, String statusBaru);
    int hitungEstimasiWaktu(double jarak);
    String tampilkanRincianPengiriman();
    String getStatus();
    void setStatus(String status);
    String getAlamatTujuan();
    void setAlamatTujuan(String alamat);
}

