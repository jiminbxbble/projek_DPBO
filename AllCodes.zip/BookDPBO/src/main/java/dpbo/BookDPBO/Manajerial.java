package dpbo.BookDPBO;

public interface Manajerial {
    String tampilkanInfoManajemen();
    String getNamaManajer();
    void setNamaManajer(String nama);
    String getUnitKerja();
    void setUnitKerja(String unit);
    String getStatusOperasional();
    void setStatusOperasional(String status);
	void kendalikan();
	void rencanakan();
}

