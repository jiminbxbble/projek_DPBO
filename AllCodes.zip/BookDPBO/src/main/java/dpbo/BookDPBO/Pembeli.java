package dpbo.BookDPBO;

public class Pembeli extends User implements KelolaToko {

    public Pembeli(String nama, String password, String alamat) {
        super(nama, password, alamat);
    }

    
    public void beliBarang(String barang, int jumlah) {
        System.out.println(nama + " membeli " + jumlah + " buah " + barang);
    }

    public void bayarBarang(double total) {
        System.out.println(nama + " membayar sebesar Rp" + total);
    }

    
    public void tambahBarang(String barang) {
        // Tidak digunakan oleh pembeli
    }

   
    public void hapusBarang(String barang) {
        // Tidak digunakan oleh pembeli
    }


	@Override
	public void kelola() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void tampilkanInfo() {
		// TODO Auto-generated method stub
		
	}


	
}

