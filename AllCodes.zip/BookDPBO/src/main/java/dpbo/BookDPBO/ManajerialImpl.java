package dpbo.BookDPBO;

import javax.swing.JOptionPane;

public class ManajerialImpl implements Manajerial {
    @Override
    public void kendalikan() {
        JOptionPane.showMessageDialog(null, "Manajemen dikendalikan.");
    }

	@Override
	public String tampilkanInfoManajemen() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNamaManajer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setNamaManajer(String nama) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getUnitKerja() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setUnitKerja(String unit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getStatusOperasional() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setStatusOperasional(String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rencanakan() {
		// TODO Auto-generated method stub
		
	}
}
