package dpbo.BookDPBO;

public abstract class User {
    protected String nama;
    protected String password;
    protected String alamat;

    public User(String nama, String password, String alamat) {
        this.nama = nama;
        this.password = password;
        this.alamat = alamat;
    }

    public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getNama() {
        return nama;
    }

    public String getPassword() {
        return password;
    }

    public void login() {
        System.out.println(nama + " login berhasil.");
    }

    public void logout() {
        System.out.println(nama + " logout.");
    }
    
    abstract void tampilkanInfo();
}

