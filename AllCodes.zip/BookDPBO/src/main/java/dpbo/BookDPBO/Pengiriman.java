package dpbo.BookDPBO;

import java.util.*;

public class Pengiriman extends Manajemen implements PengirimanInterface {
    private String idPengiriman;
    private List<String> daftarPesanan = new ArrayList<>();
    private String alamatTujuan;
    private String status;
    private String kurir;
    private int estimasiWaktu;
    private String metodePengiriman;

    public Pengiriman(String idPengiriman, String alamatTujuan, String status) {
        this.idPengiriman = idPengiriman;
        this.alamatTujuan = alamatTujuan;
        this.status = status;
        this.kurir = kurir;
        this.metodePengiriman = metodePengiriman;
    }

    public void aturPengiriman(String pesananId) {
        daftarPesanan.add(pesananId);
        logAktivitas.add("Pesanan " + pesananId + " ditambahkan ke pengiriman " + idPengiriman);
    }

    public void updateStatusPengiriman(String id, String statusBaru) {
        if (this.idPengiriman.equals(id)) {
            this.status = statusBaru;
            logAktivitas.add("Status pengiriman " + id + " diubah menjadi: " + statusBaru);
        }
    }

    public int hitungEstimasiWaktu(double jarak) {
        int kecepatan = 50;
        this.estimasiWaktu = (int) Math.ceil(jarak / kecepatan);
        return this.estimasiWaktu;
    }

    public String tampilkanRincianPengiriman() {
        return "Pengiriman ID: " + idPengiriman +
                "\nAlamat Tujuan: " + alamatTujuan +
                "\nKurir: " + kurir +
                "\nMetode: " + metodePengiriman +
                "\nStatus: " + status +
                "\nJumlah Pesanan: " + daftarPesanan.size() +
                "\nEstimasi Waktu: " + estimasiWaktu + " hari";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAlamatTujuan() {
        return alamatTujuan;
    }

    public void setAlamatTujuan(String alamat) {
        this.alamatTujuan = alamat;
    }

	public void kirimBarang() {
		// TODO Auto-generated method stub
		
	}
}
