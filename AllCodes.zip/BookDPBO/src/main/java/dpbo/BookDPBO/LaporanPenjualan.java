package dpbo.BookDPBO;

import java.util.*;

public class LaporanPenjualan extends Manajemen implements LaporanInterface {
    private String idLaporan;
    private Date tanggalMulai;
    private Date tanggalAkhir;
    private double totalPenjualan;
    private int jumlahBukuTerjual;
    private String kategoriTerlaris;
    private double rataRataPenjualanHarian;

    public LaporanPenjualan() {
        this.idLaporan = "L001";
        this.kategoriTerlaris = "Fiksi";
        this.tanggalMulai = new GregorianCalendar(2025, Calendar.JANUARY, 1).getTime();
        this.tanggalAkhir = new GregorianCalendar(2025, Calendar.JUNE, 1).getTime();
        this.totalPenjualan = 1500000.0;
        this.jumlahBukuTerjual = 100;
    }

    public LaporanPenjualan(String idLaporan, String kategoriTerlaris, Date tanggalMulai, Date tanggalAkhir, double totalPenjualan, int jumlahBukuTerjual) {
        this.idLaporan = idLaporan;
        this.kategoriTerlaris = kategoriTerlaris;
        this.tanggalMulai = tanggalMulai;
        this.tanggalAkhir = tanggalAkhir;
        this.totalPenjualan = totalPenjualan;
        this.jumlahBukuTerjual = jumlahBukuTerjual;
    }

    public void generateLaporanPenjualan() {
        logAktivitas.add("Laporan " + idLaporan + " dibuat pada " + new Date());
    }

    public double hitungRataRataPenjualan() {
        long hari = (tanggalAkhir.getTime() - tanggalMulai.getTime()) / (1000 * 60 * 60 * 24);
        if (hari == 0) hari = 1;
        this.rataRataPenjualanHarian = totalPenjualan / hari;
        return rataRataPenjualanHarian;
    }

    public String tampilkanLaporan() {
        hitungRataRataPenjualan();
        return "Laporan Penjualan ID: " + idLaporan +
                "\nPeriode: " + tanggalMulai + " - " + tanggalAkhir +
                "\nTotal Penjualan: Rp" + totalPenjualan +
                "\nJumlah Buku Terjual: " + jumlahBukuTerjual +
                "\nKategori Terlaris: " + kategoriTerlaris +
                "\nRata-rata Penjualan Harian: Rp" + String.format("%.2f", rataRataPenjualanHarian);
    }

    public String bandingkanPeriode(Date tglAwal, Date tglAkhir) {
        return "Membandingkan laporan antara " + tglAwal + " dan " + tglAkhir;
    }

    public double getTotalPenjualan() {
        return totalPenjualan;
    }

    public void setTotalPenjualan(double total) {
        this.totalPenjualan = total;
    }

    public int getJumlahBukuTerjual() {
        return jumlahBukuTerjual;
    }

    public void setJumlahBukuTerjual(int jumlah) {
        this.jumlahBukuTerjual = jumlah;
    }
}
