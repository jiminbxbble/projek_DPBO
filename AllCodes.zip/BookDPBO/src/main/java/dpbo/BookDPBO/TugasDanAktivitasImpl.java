package dpbo.BookDPBO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TugasDanAktivitasImpl implements TugasDanAktivitas {
    private ArrayList<Transaksi> daftarTransaksi;

    public TugasDanAktivitasImpl(ArrayList<Transaksi> daftarTransaksi) {
        this.daftarTransaksi = daftarTransaksi;
    }

    @Override
    public void laksanakanTugas() {
        if (daftarTransaksi == null || daftarTransaksi.isEmpty()) {
            System.out.println("Belum ada aktivitas pembeli yang tercatat.");
            return;
        }

        System.out.println("\n=== AKTIVITAS PEMBELI ===");
        for (Transaksi t : daftarTransaksi) {
            System.out.println("Nama Pembeli   : " + t.getNama());
            System.out.println("Tanggal Beli   : " + t.getTanggal());
            System.out.println("Buku Dibeli    : " + t.getBuku());
            System.out.println("Jumlah         : " + t.getJumlah());
            System.out.println("Total Bayar    : Rp" + t.getTotalHarga());
            System.out.println("----------------------------");
        }
    }

    public void lacakAktivitasPembeli(String namaPembeli) {
        boolean ditemukan = false;
        System.out.println("\nAktivitas untuk pembeli: " + namaPembeli);
        for (Transaksi t : daftarTransaksi) {
            if (t.getNama().equalsIgnoreCase(namaPembeli)) {
                ditemukan = true;
                System.out.println("Tanggal Beli : " + t.getTanggal());
                System.out.println("Buku Dibeli  : " + t.getBuku());
                System.out.println("Jumlah       : " + t.getJumlah());
                System.out.println("Total Bayar  : Rp" + t.getTotalHarga());
                System.out.println("----------------------------");
            }
        }

        if (!ditemukan) {
            System.out.println("Tidak ditemukan aktivitas untuk pembeli bernama \"" + namaPembeli + "\".");
        }
    }

	@Override
	public void jadwalkanTugas(String tugas, Date tanggal) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<String> rekapAktivitas() {
		// TODO Auto-generated method stub
		return null;
	}
}
