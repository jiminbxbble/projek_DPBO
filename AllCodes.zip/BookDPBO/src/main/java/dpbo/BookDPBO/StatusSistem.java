package dpbo.BookDPBO;

public interface StatusSistem {
    String tampilkanStatusSistem();
    void aktifkanUnit();
    void nonaktifkanUnit();
}

