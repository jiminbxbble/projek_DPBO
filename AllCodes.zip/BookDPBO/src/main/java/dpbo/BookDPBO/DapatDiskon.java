package dpbo.BookDPBO;
public interface DapatDiskon {
	public double hitungHargaDiskon();
}
