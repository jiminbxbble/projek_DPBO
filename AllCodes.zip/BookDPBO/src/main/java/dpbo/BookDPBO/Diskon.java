package dpbo.BookDPBO;

	public class Diskon extends Produk implements DapatDiskon{
	    private int persenDiskon;

	    public Diskon(String namaProduk, double harga, int stok, int persenDiskon) {
			super(namaProduk, harga, stok);
			
			 if (persenDiskon < 0 || persenDiskon > 100) {
			        throw new IllegalArgumentException("[ERROR] Diskon yang dimasukkan tidak sesuai");
			    }
			 
			this.persenDiskon = persenDiskon;
		}
	    
	    public Diskon(String namaProduk, double harga, int stok) {
			super(namaProduk, harga, stok);
			
	    }
	    public int getPersenDiskon() {
			return persenDiskon;
		}

		public void setPersenDiskon(int persenDiskon) {
			this.persenDiskon = persenDiskon;
		}

		public double hitungHargaDiskon() {
	        return getHarga() - (getHarga() * persenDiskon / 100);
	    }

		@Override
		public String toString() {
			return "Pembelian "+ super.getJenisProduk()+ " mendapatkan Diskon " + persenDiskon + " % sehingga total harga menjadi Rp" + hitungHargaDiskon();
		}
	}

