package dpbo.BookDPBO;

import java.time.LocalDate;

public class Transaksi {
    private String tanggal;
    private String nama;
    private String alamat;
    private String buku;
    private int jumlah;
    private int totalHarga;

    // Tambahan field objek
    private Pembeli pembeli;
    private Buku bukuObj;
    private Produk produk;  // <- Tambahan ini

    public Transaksi(String tanggal, String nama, String alamat, String buku, int jumlah, int totalHarga) {
        this.tanggal = tanggal;
        this.nama = nama;
        this.alamat = alamat;
        this.buku = buku;
        this.jumlah = jumlah;
        this.totalHarga = totalHarga;
    }

    public Transaksi(Penjual penjual, Pembeli pembeli, Buku bukuObj, int jumlah) {
        this.tanggal = LocalDate.now().toString();
        this.nama = pembeli.getNama();
        this.alamat = pembeli.getAlamat(); 
        this.buku = bukuObj.getJudulBuku();
        this.jumlah = jumlah;
        this.totalHarga = (int) bukuObj.getHarga() * jumlah;

        this.pembeli = pembeli;
        this.bukuObj = bukuObj;
        this.produk = bukuObj;
    }

    public Pembeli getPembeli() {
        return pembeli;
    }

    public Buku getBukuObj() {
        return bukuObj;
    }

    public Produk getProduk() {
        return produk;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getBuku() {
        return buku;
    }

    public int getJumlah() {
        return jumlah;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public void konfirmasiPembayaran() {
        System.out.println("Pembayaran telah dikonfirmasi.");
    }

    public void prosesTransaksi() {
        System.out.println("\n--- Transaksi Diproses ---");
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "Transaksi pada tanggal " + tanggal + ", atas nama " + nama +
                ", dengan alamat " + alamat + ", judul buku yang dibeli " +
                buku + " sebanyak " + jumlah + " buku, dan dengan total harga Rp. " + totalHarga;
    }
}
