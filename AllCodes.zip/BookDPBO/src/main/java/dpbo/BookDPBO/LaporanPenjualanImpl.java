package dpbo.BookDPBO;

import java.util.ArrayList;
import java.util.Date;

public class LaporanPenjualanImpl implements LaporanInterface {
    private ArrayList<Transaksi> daftarTransaksi;

    public LaporanPenjualanImpl(ArrayList<Transaksi> daftarTransaksi) {
        this.daftarTransaksi = daftarTransaksi;
    }

    @Override
    public String tampilkanLaporan() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n=== LAPORAN PENJUALAN ===\n");

        if (daftarTransaksi == null || daftarTransaksi.isEmpty()) {
            sb.append("Belum ada transaksi yang tercatat.\n");
            return sb.toString();
        }

        for (Transaksi t : daftarTransaksi) {
            sb.append("Tanggal     : ").append(t.getTanggal()).append("\n");
            sb.append("Nama        : ").append(t.getNama()).append("\n");
            sb.append("Alamat      : ").append(t.getAlamat()).append("\n");
            sb.append("Judul Buku  : ").append(t.getBuku()).append("\n");
            sb.append("Jumlah      : ").append(t.getJumlah()).append("\n");
            sb.append("Total Harga : Rp").append(t.getTotalHarga()).append("\n");
            sb.append("---------------------------\n");
        }

        return sb.toString();
    }

    @Override
    public void generateLaporanPenjualan() {
        // Implementasi bisa ditambahkan jika diperlukan
    }

    @Override
    public double hitungRataRataPenjualan() {
        // Placeholder
        return 0;
    }

    @Override
    public String bandingkanPeriode(Date tglAwal, Date tglAkhir) {
        // Placeholder
        return null;
    }

    @Override
    public double getTotalPenjualan() {
        // Placeholder
        return 0;
    }

    @Override
    public void setTotalPenjualan(double total) {
        // Placeholder
    }

    @Override
    public int getJumlahBukuTerjual() {
        // Placeholder
        return 0;
    }

    @Override
    public void setJumlahBukuTerjual(int jumlah) {
        // Placeholder
    }
}
