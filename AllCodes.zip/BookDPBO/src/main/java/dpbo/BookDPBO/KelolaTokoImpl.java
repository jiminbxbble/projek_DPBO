package dpbo.BookDPBO;

import javax.swing.JOptionPane;

public class KelolaTokoImpl implements KelolaToko {
    @Override
    public void kelola() {
        JOptionPane.showMessageDialog(null, "Fungsi kelola toko dijalankan.");
    }

	@Override
	public void tambahBarang(String barang) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hapusBarang(String barang) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beliBarang(String barang, int jumlah) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bayarBarang(double total) {
		// TODO Auto-generated method stub
		
	}
}

