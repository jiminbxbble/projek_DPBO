package DPBO.tubesDPBO;

public class Main {
    public static void main(String[] args) {
        Buku buku1 = new Buku("novel", 100000, 10, "laut bercerita", "Budi", "fiksi");

        System.out.println("=== Data Pembelian ===");
        System.out.println("jenis Produk: " + buku1.getJenisProduk());
        System.out.println("Judul Buku  : " + buku1.getJudulBuku());
        System.out.println("Penulis     : " + buku1.getPenulis());
        System.out.println("Genre       : " + buku1.getGenre());
        System.out.println("Harga       : Rp" + buku1.getHarga());
        System.out.println("Stok Awal   : " + buku1.getStok());

        // Simulasi pembelian 3 buku
        int jumlahBeli = 2;
        if (buku1.beli(jumlahBeli)) {
            // Buat objek Diskon dengan harga dan stok terbaru (stok sudah berkurang)
            Diskon produkDiskon = new Diskon(buku1.getJenisProduk(), buku1.getHarga(), buku1.getStok(), 50);

            System.out.println("\n=== Harga Setelah Diskon ===");
            System.out.println(produkDiskon.toString());

            System.out.println("\n=== Sisa Stok Buku ===");
            System.out.println("Sisa stok novel laut bercerita : " + buku1.getStok());
        } else {
            System.out.println("Stok tidak cukup untuk pembelian " + jumlahBeli + " buku.");
        }
    }
}
