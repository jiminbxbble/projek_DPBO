package DPBO.tubesDPBO;

public abstract class Produk {
	    private String jenisProduk;
	    private double harga;
	    private int stok;
	   
		public Produk(String jenisProduk, double harga, int stok) {
			this.jenisProduk = jenisProduk;
			this.harga = harga;
			this.stok = stok;
		}
		
		public String getJenisProduk() {
			return jenisProduk;
		}

		public void setJenisProduk(String jenisProduk) {
			this.jenisProduk = jenisProduk;
		}

		public double getHarga() {
			return harga;
		}

		public void setHarga(double harga) {
			this.harga = harga;
		}

		public int getStok() {
			return stok;
		}

		public void setStok(int stok) {
			this.stok = stok;
		}
		
		public boolean beli(int jumlah) {
			if (jumlah <= 0) {
		        throw new IllegalArgumentException("[ERROR] Stok tidak mencukupi dengan jumlah pembelian ");
		    }
			if (jumlah <= stok) {  
		        stok -= jumlah;    
		        return true;
		    } else {
		        return false;      
		    }
		}
		@Override
		public String toString() {
			return "Jenis Produk: " + jenisProduk + ", harga: " + harga + ", stok: " + stok;
		}
}
