package DPBO.Transaksi;

public class Transfer extends Transaksi implements Pembayaran {
	private String bank;
	private String noVirtualAccount;
	
	public Transfer(String tanggal, String nama, String alamat, String buku, int jumlah, 
			int totalHarga, String bank, String noVirtualAccount) {
		super(tanggal, nama, alamat, buku, jumlah, totalHarga);
		this.bank = bank;
		this.noVirtualAccount = noVirtualAccount;
	}
	
	public String getNoVirtualAccount() {
		return noVirtualAccount;
	}
	
	public void setNoVirtualAccount(String noVA) {
		this.noVirtualAccount = noVA;
	}
	
	public String getBank() {
		return bank;
	}

	@Override
	public void bayar() {
		System.out.println("Pembayaran melalui transfer ke " + bank + " berhasil.");
	}
}
