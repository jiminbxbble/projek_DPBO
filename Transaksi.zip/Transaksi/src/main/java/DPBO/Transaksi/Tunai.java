package DPBO.Transaksi;

public class Tunai extends Transaksi implements Pembayaran {
	private boolean statusTransaksi;

	public Tunai(String tanggal, String nama, String alamat, String buku, int jumlah, 
			int totalHarga, boolean statusTransaksi) {
		super(tanggal, nama, alamat, buku, jumlah, totalHarga);
		this.statusTransaksi = statusTransaksi;
	}

	public boolean isStatusTransaksi() {
		return statusTransaksi;
	}

	public void setStatusTransaksi(boolean statusTransaksi) {
		this.statusTransaksi = statusTransaksi;
	}

	@Override
	public void bayar() {
		this.statusTransaksi = true;
        System.out.println("Pembayaran tunai berhasil.");
	}

}
