package DPBO.Transaksi;

public interface Pembayaran {
	public void bayar();
}
