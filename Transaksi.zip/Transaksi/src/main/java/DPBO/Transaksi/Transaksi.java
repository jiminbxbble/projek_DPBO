package DPBO.Transaksi;

public class Transaksi {
	private String tanggal;
	private String nama;
	private String alamat;
	private String buku;
	private int jumlah;
	private int totalHarga;
	
	public Transaksi(String tanggal, String nama, String alamat, String buku, int jumlah, int totalHarga) {
		this.tanggal = tanggal;
		this.nama = nama;
		this.alamat = alamat;
		this.buku = buku;
		this.jumlah = jumlah;
		this.totalHarga = totalHarga;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getTanggal() {
		return tanggal;
	}

	public String getBuku() {
		return buku;
	}

	public int getJumlah() {
		return jumlah;
	}

	public int getTotalHarga() {
		return totalHarga;
	}
	
	public void konfirmasiPembayaran() {
		System.out.println("Pembayaran telah dikonfirmasi");
	}

	@Override
	public String toString() {
		return "Transaksi pada tanggal "+ tanggal + ", atas nama " + nama + ", dengan alamat " + alamat + ", judul buku yang dibeli " 
				+ buku + " sebanyak " + jumlah + " buku, dan dengan total harga Rp. " + totalHarga;
	}
	
	
	
	
}
