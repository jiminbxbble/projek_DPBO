package ProjectUser;

public interface KelolaToko {
    void tambahBarang(String barang);
    void hapusBarang(String barang);
    void beliBarang(String barang, int jumlah);
    void bayarBarang(double total);
}

