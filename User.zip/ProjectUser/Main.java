package ProjectUser;

public class Main {
    public static void main(String[] args) {
        Pembeli pembeli = new Pembeli("budi", "1234");
        Penjual penjual = new Penjual("sari", "abcd");

        pembeli.login();
        pembeli.beliBarang("Laptop", 1);
        pembeli.bayarBarang(15000000);
        pembeli.logout();

        penjual.login();
        penjual.tambahBarang("Mouse");
        penjual.hapusBarang("Keyboard");
        penjual.logout();
    }
}
