package ProjectUser;

public class Penjual extends User implements KelolaToko {

   

    public Penjual(String username, String password) {
    	super(username, password);
		// TODO Auto-generated constructor stub
	}

	
    public void tambahBarang(String barang) {
        System.out.println(username + " menambahkan barang: " + barang);
    }

    
    public void hapusBarang(String barang) {
        System.out.println(username + " menghapus barang: " + barang);
    }

    
    public void beliBarang(String barang, int jumlah) {
        // Tidak digunakan oleh penjual
    }

  
    public void bayarBarang(double total) {
        // Tidak digunakan oleh penjual
    }
}

