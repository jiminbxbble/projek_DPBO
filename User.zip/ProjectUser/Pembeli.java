package ProjectUser;

public class Pembeli extends User implements KelolaToko {

    public Pembeli(String username, String password) {
        super(username, password);
    }

    
    public void beliBarang(String barang, int jumlah) {
        System.out.println(username + " membeli " + jumlah + " buah " + barang);
    }

    public void bayarBarang(double total) {
        System.out.println(username + " membayar sebesar Rp" + total);
    }

    
    public void tambahBarang(String barang) {
        // Tidak digunakan oleh pembeli
    }

   
    public void hapusBarang(String barang) {
        // Tidak digunakan oleh pembeli
    }
}

