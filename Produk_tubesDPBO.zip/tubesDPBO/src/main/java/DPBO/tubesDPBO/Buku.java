package DPBO.tubesDPBO;

	public class Buku extends Produk {
	    private String judulBuku;
	    private String penulis;
	    
		public Buku(String nama, double harga, int stok, String judulBuku, String penulis) {
			super(nama, harga,stok);
			this.judulBuku = judulBuku;
			this.penulis = penulis;
		}
		
		public String getJudulBuku() {
			return judulBuku;
		}

		public void setJudulBuku(String judulBuku) {
			this.judulBuku = judulBuku;
		}
		
		public String getPenulis() {
			return penulis;
		}

		public void setPenulis(String penulis) {
			this.penulis = penulis;
		}

		@Override
		public String toString() {
			return super.toString() + "\n Judul Buku: " + judulBuku + ", penulis: " + penulis;
		}
}
