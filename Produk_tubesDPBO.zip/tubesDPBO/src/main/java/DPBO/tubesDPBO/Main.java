package DPBO.tubesDPBO;


public class Main {
    public static void main(String[] args) {
        Buku buku1 = new Buku("buku pelajaran", 100000, 10, "Belajar Java", "Budi");

        System.out.println("=== Data Buku ===");
        System.out.println(buku1.toString());

        Diskon produkDiskon = new Diskon("buku pelajaran", 200000, 5, 20);

        System.out.println("\n=== Data Produk Diskon ===");
        System.out.println(produkDiskon.toString());

        System.out.println("Harga setelah diskon: Rp" + produkDiskon.hitungHargaDiskon());
    }
}
