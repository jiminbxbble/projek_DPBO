package DPBO.tubesDPBO;

	public class Diskon extends Produk implements DapatDiskon{
	    private int persenDiskon;

	    public Diskon(String namaProduk, double harga, int stok, int persenDiskon) {
			super(namaProduk, harga, stok);
			this.persenDiskon = persenDiskon;
		}
	    
	    public int getPersenDiskon() {
			return persenDiskon;
		}

		public void setPersenDiskon(int persenDiskon) {
			this.persenDiskon = persenDiskon;
		}

		public double hitungHargaDiskon() {
	        return getHarga() - (getHarga() * persenDiskon / 100);
	    }

		@Override
		public String toString() {
			return "Pembelian"+ super.getNamaProduk()+ " mendapatkan Diskon " + persenDiskon + " % sehingga total harga menjadi Rp" + hitungHargaDiskon();
		}
	}

