package DPBO.tubesDPBO;
public interface DapatDiskon {
	public double hitungHargaDiskon();
}
